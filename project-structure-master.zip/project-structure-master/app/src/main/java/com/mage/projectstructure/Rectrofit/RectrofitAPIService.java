package com.mage.projectstructure.Rectrofit;

import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;


public interface RectrofitAPIService {
    @Headers({
            "Accept: application/json",
            "Content-Type: application/json"
    })

    //User Login
    @POST("MemberLogin")
    Call<JsonObject> postLoginJSON(@Body JsonObject jsonObject);
}
