package com.mage.projectstructure.uc;

import android.graphics.Rect;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

public class SpacesItemDecoration extends RecyclerView.ItemDecoration {
    private int space;

  //  private final int spacing;
    private int displayMode;

    public static final int HORIZONTAL = 0;
    public static final int VERTICAL = 1;
    public static final int GRID = 2;



    public SpacesItemDecoration(int space, int displayMode) {
        this.space = space;
        this.displayMode = displayMode;
    }

    @Override
    public void getItemOffsets(Rect outRect, View view,
                               RecyclerView parent, RecyclerView.State state) {
        /*outRect.right = space;
        outRect.bottom = space;*/

        int position = parent.getChildViewHolder(view).getAdapterPosition();
        int itemCount = state.getItemCount();
        RecyclerView.LayoutManager layoutManager = parent.getLayoutManager();
        setSpacingForDirection(outRect, layoutManager, position, itemCount);



       /* outRect.left = space;
        outRect.top = space;*/
       // view.setBackgroundColor(Color.WHITE);

        // Add top margin only for the first item to avoid double space between items
      /*  if (parent.getChildLayoutPosition(view) == 0) {
            outRect.top = space;
        } else {
            outRect.top = 0;
        }*/
    }

    private void setSpacingForDirection(Rect outRect,
                                        RecyclerView.LayoutManager layoutManager,
                                        int position,
                                        int itemCount) {

        // Resolve display mode automatically
        if (displayMode == -1) {
            displayMode = resolveDisplayMode(layoutManager);
        }

        switch (displayMode) {
            case HORIZONTAL:
                outRect.left = space;
                outRect.right = position == itemCount - 1 ? space : 0;
                outRect.top = space;
                outRect.bottom = space;
                break;
            case VERTICAL:
                outRect.left = space;
                outRect.right = space;
                outRect.top = space;
                outRect.bottom = position == itemCount - 1 ? space : 0;
                break;
            case GRID:
                if (layoutManager instanceof GridLayoutManager) {
                    GridLayoutManager gridLayoutManager = (GridLayoutManager) layoutManager;
                    int cols = gridLayoutManager.getSpanCount();
                    int rows = itemCount / cols;

                    outRect.left = space;
                    outRect.right = position % cols == cols - 1 ? space : 0;
                    outRect.top = space;
                    outRect.bottom = position / cols == rows - 1 ? space : 0;
                }
                break;
        }
    }

    private int resolveDisplayMode(RecyclerView.LayoutManager layoutManager) {
        if (layoutManager instanceof GridLayoutManager) return GRID;
        if (layoutManager.canScrollHorizontally()) return HORIZONTAL;
        return VERTICAL;
    }


}
