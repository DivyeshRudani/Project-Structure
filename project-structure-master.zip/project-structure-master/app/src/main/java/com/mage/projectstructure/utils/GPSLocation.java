package com.mage.projectstructure.utils;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.util.Log;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;


public class GPSLocation {

    public static LocationManager mNetLocationManager = null;
    public static LocationManager mGPSLocationManager = null;

    public static LocationListener locationListener = null;

    public static boolean isGpsEnabled = false;
    private boolean isNetworkEnabled = false;
    private AlertDialog.Builder mDialog;
    private Context mContext;
    public static double lat = 0.0;
    public static double lng = 0.0;
    private String TAG = "------------";
    Activity mActivity;

    public boolean getGPSLocation(final Context context, boolean toShow, Activity activity) {

        mContext = context;
        mActivity = activity;
        //TAG = mContext.getClass().getName();
        if (GPSLocation.mGPSLocationManager == null)
            GPSLocation.mGPSLocationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);

        if (GPSLocation.mNetLocationManager == null)
            GPSLocation.mNetLocationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);

        if (GPSLocation.locationListener == null)
            GPSLocation.locationListener = new LocationListener() {

                public void onLocationChanged(Location location) {
                    if (location != null)
                        Utils.print(">>>>>> ACUURECY ::::: ", String.valueOf(location.getAccuracy()));

                    if (location != null && location.getAccuracy() < 100) {

                        lat = location.getLatitude();
                        lng = location.getLongitude();
//
//                        lat =25.037090;
//                        lng=121.561752;

                        Pref.setStringValue(mContext, Const.currentlat, lat + "");
                        Pref.setStringValue(mContext, Const.currentlng, lng + "");

                        Intent intent = new Intent();
                        intent.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
                        intent.setAction("LOCATION_CHANGE");
                        intent.putExtra("ISDISABLE", false);
                        context.sendBroadcast(intent);

                        Utils.print(" === LOCATION CHANGE=== lat " + lat + ":::" + lng);
                    /*
                     * if (mLocationManager != null) {
					 * mLocationManager.removeUpdates(this);
					 * mLocationManager.removeUpdates(locationListenerGps); }
					 */
                    }
                }

                public void onProviderDisabled(String provider) {
                    Utils.print(" ======================== LOCATION onProviderDisabled <<<<<<<<<<<<<<<<<<<< ");
                    Intent intent = new Intent();
                    intent.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
                    intent.setAction("LOCATION_CHANGE");
                    intent.putExtra("ISDISABLE", true);
                    context.sendBroadcast(intent);
                    unregister();
                }

                public void onProviderEnabled(String provider) {
                    if (context != null)
                        getGPSLocation(context, false, mActivity);
                    Utils.print(" ======================== LOCATION onProviderEnabled <<<<<<<<<<<<<<<<<<<< ");
                }

                public void onStatusChanged(String provider, int status, Bundle extras) {
                    Utils.print(" ======================== LOCATION onStatusChanged <<<<<<<<<<<<<<<<<<<< ");
                }
            };

        try {
            isGpsEnabled = GPSLocation.mGPSLocationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            isNetworkEnabled = GPSLocation.mNetLocationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

        } catch (Exception e) {
            // Exception: No suitable permission is present for the provider.
            Const.PROVIDER_EXCEPTION = e.getMessage();
            return false;
        }
        if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            if (isGpsEnabled)
                GPSLocation.mGPSLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 10, GPSLocation.locationListener);

            if (isNetworkEnabled)
                GPSLocation.mNetLocationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 10, GPSLocation.locationListener);
        }

        Utils.print("Is provider enabled?", "GPS_PROVIDER : " + isGpsEnabled
                + " & network_provider : " + isNetworkEnabled);

        // don't start listeners if no provider is enabled
        if (!isGpsEnabled && !isNetworkEnabled && toShow) {


		/*	mDialog = new AlertDialog.Builder(context);
            mDialog.setMessage(context.getResources().getString(
					R.string.gps_network_not_enabled));
			mDialog.setPositiveButton(
					context.getResources().getString(
							R.string.open_location_settings),
					new DialogInterface.OnClickListener() {

						public void onClick(
								DialogInterface paramDialogInterface,
								int paramInt) {
							Intent myIntent = new Intent(
									Settings.ACTION_LOCATION_SOURCE_SETTINGS);
							context.startActivity(myIntent);

							Const.IS_FROM_GPSLOCATION = true;
							// checkForProviders(mLocationManager);
							// to check once more for providers
							// getGPSLocation(context);
						}
					});
			mDialog.setNegativeButton(context.getString(R.string.cancel),
					new DialogInterface.OnClickListener() {

						public void onClick(
								DialogInterface paramDialogInterface,
								int paramInt) {
							// what you wanna show if user has clicked cancel
							// button?
							// It is based on project requirement.
						}
					});

				mDialog.show();*/
            displayLocationSettingsRequest(mContext);

            return false;
        }

        return true;
    }

    public void unregister() {
        try {
            if (GPSLocation.locationListener != null) {
                if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    GPSLocation.mGPSLocationManager.removeUpdates(GPSLocation.locationListener);
                    GPSLocation.mNetLocationManager.removeUpdates(GPSLocation.locationListener);
                }
                GPSLocation.locationListener = null;
                lat = 0.0;
                lng = 0.0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void displayLocationSettingsRequest(final Context context) {
        GoogleApiClient googleApiClient = new GoogleApiClient.Builder(context)
                .addApi(LocationServices.API).build();
        googleApiClient.connect();

        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(10000 / 2);

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addLocationRequest(locationRequest);
        builder.setAlwaysShow(true);

        PendingResult<LocationSettingsResult> result = LocationServices.SettingsApi.checkLocationSettings(googleApiClient, builder.build());
        result.setResultCallback(new ResultCallback<LocationSettingsResult>() {
            @Override
            public void onResult(LocationSettingsResult result) {
                final Status status = result.getStatus();
                switch (status.getStatusCode()) {
                    case LocationSettingsStatusCodes.SUCCESS:
                        Log.i(TAG, "All location settings are satisfied.");
                        Const.IS_FROM_GPSLOCATION = true;
                        break;
                    case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                        Log.i(TAG, "Location settings are not satisfied. Show the user a dialog to upgrade location settings ");

                        try {
                            // Show the dialog by calling startResolutionForResult(), and check the result
                            // in onActivityResult().
                            status.startResolutionForResult(mActivity, Const.INTENT100);
                        } catch (IntentSender.SendIntentException e) {
                            Log.i(TAG, "PendingIntent unable to execute request.");
                        }
                        break;
                    case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                        Log.i(TAG, "Location settings are inadequate, and cannot be fixed here. Dialog not created.");
                        break;
                }
            }
        });
    }

}
