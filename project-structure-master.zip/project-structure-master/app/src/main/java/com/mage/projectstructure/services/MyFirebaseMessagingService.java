package com.mage.projectstructure.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.mage.projectstructure.R;
import com.mage.projectstructure.app.Config;
import com.mage.projectstructure.ui.MainActivity;
import com.mage.projectstructure.util.NotificationUtils;
import com.mage.projectstructure.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by ms-02 on 20/11/17.
 */

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = MyFirebaseMessagingService.class.getSimpleName();

    private NotificationUtils notificationUtils;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        Log.d(TAG, "remoteMessage: " + remoteMessage.getData());
        Log.d(TAG, "From: " + remoteMessage.getFrom());

       // parsing(remoteMessage.getData().toString());

        Intent pushNotification = new Intent(Config.PUSH_NOTIFICATION);
        LocalBroadcastManager.getInstance(this).sendBroadcast(pushNotification);
    }

    private void parsing(String data) {
        try {

            JSONObject jsonObject = new JSONObject(data);
            /*
             * {contentTitle=content title GCM, message=test, tickerText=example test GCM}
             * */
            JSONObject jsonObj;
            if (jsonObject.has("data")) {
                jsonObj = jsonObject.getJSONObject("data");
                Utils.print("title: " + jsonObj.getString("subject"));
                Utils.print("message: " + jsonObj.getString("title"));
                Utils.print("timestamp: " + jsonObj.getString("body"));


                createNotificationPlayer(jsonObj.getString("subject"), jsonObj.getString("title"));
            }

        } catch (JSONException e) {
            e.printStackTrace();// ignore this error ,this error not show if user come from notification   otherwise its shows always
            createNotificationPlayer(data, getResources().getString(R.string.app_name));
        }
    }

    //for oreo
    public void createNotificationPlayer(String message, String title) {

        NotificationManager notificationManager = null;
        Notification notification = null;
        NotificationCompat.Builder notificationCompat = null;
        int NOTIFICATION_ID = 234;

        Intent openUi = new Intent(this, MainActivity.class);
        openUi.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
       // JcAudioPlayer.getInstance().registerNotificationListener(this);

        if (notificationManager == null) {
            notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        }
        //String channelId = "fcm_default_channel";


        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {

            //Utils.print("Oreo");

            String CHANNEL_ID = "my_channel_01";
            CharSequence name = "my_channel";
            String Description = "This is my channel";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel mChannel = new NotificationChannel(CHANNEL_ID, name, importance);
            mChannel.setDescription(Description);
            mChannel.enableLights(true);
            mChannel.setLightColor(Color.RED);
            mChannel.enableVibration(true);
            mChannel.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});
            mChannel.setShowBadge(false);
            notificationManager.createNotificationChannel(mChannel);

            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle(title)
                    .setAutoCancel(true)
                    .setContentText(message);

            Intent resultIntent = new Intent(this, MainActivity.class);
            TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
            stackBuilder.addParentStack(MainActivity.class);
            stackBuilder.addNextIntent(resultIntent);
            PendingIntent resultPendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);

            builder.setContentIntent(resultPendingIntent);

            notificationManager.notify(NOTIFICATION_ID, builder.build());

        }



       /* if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notification = new Notification.Builder(this, channelId)
                    .setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setSmallIcon(R.drawable.ic_app_icon)
                    .setContentTitle(title)
//                    .setLargeIcon(BitmapFactory.decodeResource(context.getResources(), iconResourceResource))
                    .setContentText(message)
                    .setAutoCancel(true)
                    .setContentIntent(PendingIntent.getActivity(this, NOTIFICATION_ID, openUi, PendingIntent.FLAG_CANCEL_CURRENT))
                    .setCategory(Notification.CATEGORY_SOCIAL)
                    .build();

            // Since android Oreo notification channel is needed.
            NotificationChannel channel = new NotificationChannel(channelId, "Channel human readable title",
                    NotificationManager.IMPORTANCE_LOW);
            channel.enableLights(false);
            channel.setSound(null, null);
            channel.enableVibration(false);

            notificationManager.notify(NOTIFICATION_ID, notification);
        } */else {

           // Utils.print("Marsh");
            notificationCompat = new NotificationCompat.Builder(this)

                    .setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle(title)
                    .setContentText(message)
                    .setAutoCancel(true)
                    .setContentIntent(PendingIntent.getActivity(this, NOTIFICATION_ID, openUi, PendingIntent.FLAG_CANCEL_CURRENT))
                    .setCategory(Notification.CATEGORY_SOCIAL);
            // Since android Oreo notification channel is needed.

            notificationManager.notify(NOTIFICATION_ID, notificationCompat.build());
        }


    }
}
