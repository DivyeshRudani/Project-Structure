package com.mage.projectstructure.utils;

import android.app.Activity;
import android.os.Environment;

import com.mage.projectstructure.common.CustomDialog;
import java.util.HashMap;


public class Const {

    public static final int INTENT100 = 100;
    public static final int INTENT200 = 200;
    public static final int INTENT300 = 300;
    public static final int INTENT400 = 400;
    public static final int INTENT500 = 500;
    public static final int INTENT700 = 700;
    public static final int TAKE_VIDEO = 600;
    public static final float ZOOM_LEVEl = 15;
    // CAMERA
    public static final int IMAGE_PICK = 5520;
    public static final int TAKE_PICTURE = 5521;
    public static final int VIDEO_PICK = 5522;
    // Server Error Message
    public static final String SERVER_NOT_RESPONDING = "Temporary Server Down.Please Try Again Later.";


    //google signin result
    public static int RC_SIGN_IN = 10;
    public static String APP_NAME = "Church Plus";
    //    public static String IMAGE_URL = "http://demo.magespider.com/weout/upload/";
    public static final String PREF_FILE = APP_NAME + "_PREF";
    public static String DB_NAME = APP_NAME + ".db";
    public static String CAPTURED_VIDEOPATH = "";
    public static String APP_HOME = Environment.getExternalStorageDirectory().getPath() + "/" + APP_NAME;
    public static String DIR_USERDATA = APP_HOME + "/userdata";
    /**
     * Google API project id registered to use GCM.
     */
    public static String PROJECT_ID = "160628684507";
    /**
     * Intent used to gcm registration finish
     */

    public static int DEVICE_TYPE = 2;//2=android 1=ios
    public static String STATUS = "status";
    public static String MESSAGE = "message";
    public static int LIMIT = 10;


    // connection timeout is set to 20 seconds
    public static int TIMEOUT_CONNECTION = 20000;
    // SOCKET TIMEOUT IS SET TO 30 SECONDS
    public static int TIMEOUT_SOCKET = 30000;
    // GPS
    public static String PROVIDER_EXCEPTION;
    public static String currentlat = "currentlat";
    public static String currentlng = "currentlng";
    public static boolean LAST_KNOWN_LOCATION = false;
    public static boolean IS_FROM_GPSLOCATION = false;
    public static String CAPTURED_IMAGE = "";
    public static String TAKE_VIDEO_PATH = "";
    public static CustomDialog custDailog = null;
    public static HashMap<String, Activity> screen_al;
    // Calender
    public static String TimeFormat_HH_mm_ss = "HH:mm:ss";
    public static String TimeFormat_hh_mm_aa = "hh:mm aa";
    public static String DateFormat_yyyy_MM_dd = "yyyy-MM-dd";
    public static String DateFormat_MM_dd_yyyy = "MM/dd/yyyy";
    public static String DOBDisplayFormat = "MMM dd, yyyy";
    public static String ParshingFromat = "dd/MM/yyy";
    public static String DATE_TIME_FORMATE = "yyyy-MM-dd'T'HH:mm:ss";


    //API
    public static String API_HOST = "";


    //Image API
    public static String API_HOST_IMAGE_UPLOAD = "";

    // All Api Action Declare here
    public static String ACTION_USER = "user";


    public static String UPLOAD_MULTIPLE_FILE = "UPLOAD_MULTIPLE_FILE";


    //All API Name Declare here
    public static String LOGIN_MEMBER_API = "MemberLogin";



    //pref value write here....
    public static String PREF_CAMERAPATH = "PREF_CAMERAPATH";
    public static String PREF_VIDEOPATH = "PREF_VIDEOPATH";
    public static String IMAGE_UPLOAD = "IMAGE_UPLOAD";
    public static String PREF_IMAGE_TYPE = "PREF_IMAGE_TYPE";
    public static String PREF_FIREBASE_TOKEN = "PREF_FIREBASE_TOKEN";


    //download image from url action
    public static String DOWNLOAD_IMAGE_ACTION = "DOWNLOAD_IMAGE_ACTION";
    public static String UPLOAD = "UPLOAD";


    // Api Response
    public static enum API_RESULT {
        SUCCESS, FAIL
    }


}