package com.mage.projectstructure.listener;


import com.mage.projectstructure.utils.Const;

public interface ResponseListener {
    // API Response Listener
    public void onResponse(String tag, Const.API_RESULT result, Object obj);

}
