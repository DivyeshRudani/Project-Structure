package com.mage.projectstructure.api;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.google.gson.JsonObject;
import com.mage.projectstructure.R;
import com.mage.projectstructure.Rectrofit.RectrofitAPIService;
import com.mage.projectstructure.Rectrofit.ServiceGenerator;
import com.mage.projectstructure.listener.DataResponseListener;
import com.mage.projectstructure.listener.ResponseListener;
import com.mage.projectstructure.utils.Const;
import com.mage.projectstructure.utils.Utils;

import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class LoginApi {
    public String message = "";
    public String title = "";
    Context context;
    ResponseListener responseListener;
    int status = 0;

    public LoginApi(Context context, ResponseListener responseListener) {
        this.context = context;
        this.responseListener = responseListener;
    }

    public Void execute(String memberId, String passWord) {
        final DataResponseListener dataResponseListener = new DataResponseListener() {
            @Override
            public void onResponse(String result) {
                if (result != null && !result.equals("")) // Success Response
                    parse(result);
                else
                    doCallBack(-2, "");
            }

            @Override
            public void onFailure(String fail) {
                doCallBack(-2, "");
            }

            @Override
            public void onFailure(String request, Exception error) {
                doCallBack(request.equalsIgnoreCase("SocketTimeoutException") ? 2 : -2, context.getString(R.string.temporary_server_down));
            }
        };

        /*
        * {
        *"Lang_type":"1",
        "MemberId": "A123456790",
        "MemberPassword": "12345",
        "DeviceType": 1,
        "DeviceToken":"123145ADSF123145ADSF123145ADSF"
}
        * */

        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("Lang_type", context.getResources().getString(R.string.langauage_type));
        jsonObject.addProperty("MemberId", memberId);
        jsonObject.addProperty("MemberPassword", passWord);
        jsonObject.addProperty("DeviceType", Const.DEVICE_TYPE);
        jsonObject.addProperty("DeviceToken", "1243747684");

        RectrofitAPIService jsonPostService = ServiceGenerator.createService(RectrofitAPIService.class, Const.API_HOST, Const.LOGIN_MEMBER_API, jsonObject);

        Call<JsonObject> call = jsonPostService.postLoginJSON(jsonObject);
        Utils.print("request :::::   " + call.request());
        call.enqueue(new Callback<JsonObject>() {

            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                try {
                    Utils.print("  Response response.isSuccessful(): ",
                            response.isSuccessful() + "");

                    if (response.isSuccessful()) {
                        String value = response.body().toString();
                        Utils.print(" _____***_____ API Response :::::: " + value);
                        dataResponseListener.onResponse(value);

                    } else
                        dataResponseListener.onFailure("API ISSUE ");

                } catch (Exception e) {
                    e.printStackTrace();
                    dataResponseListener.onFailure("IOEXCEPTION", e);
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Log.e("response-failure", call.toString());
                Utils.print("::::::::::::::::::::doPostRequest::::::::::onFailure::::::::::::::::::::::::::::::" + call.toString());
                Utils.print(this.getClass() + " :: Exception :: ", call.toString());
                if (call.toString().contains("SocketTimeoutException"))
                    dataResponseListener.onFailure("SocketTimeoutException", (Exception) t);
                else
                    dataResponseListener.onFailure(call.toString(), (Exception) t);
            }
        });
        return null;
    }

    private void parse(String result) {
        JSONObject jsonDoc = null;

        try {
            Utils.print("result", result);
            jsonDoc = new JSONObject(result);
            status = jsonDoc.getInt("Status");
            message = jsonDoc.getString("Message");
            title = jsonDoc.getString("Title");


            if (status == 1) {

                if (jsonDoc.has("Data")) {
                    Object obj = jsonDoc.get("Data");

                    if (obj instanceof JSONObject) {
                        JSONObject objData = jsonDoc.getJSONObject("Data");
                    }
                }
            } else if (status == 3) {

                if (jsonDoc.has("Data")) {
                    Object obj = jsonDoc.get("Data");

                    if (obj instanceof JSONObject) {
                        JSONObject objData = jsonDoc.getJSONObject("Data");
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        this.doCallBack(status, message);
    }

    private void doCallBack(final int code, final String msg) {
        ((Activity) context).runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (code == 1) {
                        responseListener.onResponse(Const.LOGIN_MEMBER_API, Const.API_RESULT.SUCCESS, code);
                        //Toast.makeText(context, "" + msg, Toast.LENGTH_SHORT).show();
                    } /*else if (code == 2) {
                        Utils.TokenExpired(context, msg);
                    }*/ else if (code > 1) {
                        //Toast.makeText(context, "" + msg, Toast.LENGTH_SHORT).show();
                        responseListener.onResponse(Const.LOGIN_MEMBER_API, Const.API_RESULT.FAIL, code);
                    } else if (code <= 0) {
                        // Utils.alertMessage(context, msg);
                        responseListener.onResponse(Const.LOGIN_MEMBER_API, Const.API_RESULT.FAIL, code);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Utils.print(this.getClass() + " ::doCallBack:: Exception :: ", "" + e);
                }
            }
        });
    }
}
