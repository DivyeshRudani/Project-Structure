package com.mage.projectstructure.backend;


import com.mage.projectstructure.listener.DataResponseListener;
import com.mage.projectstructure.utils.Const;
import com.mage.projectstructure.utils.Utils;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import java.io.IOException;
import java.net.SocketTimeoutException;


public class WebInterface {

    public static final MediaType JSON = MediaType
            .parse("application/json; charset=utf-8");
    public static String TAG = "WebInterface";
    public static String auth = "auth-token";
    static OkHttpClient client = null;
    static Request request = null;
    static Call call = null;

    public static void doPostRequest(String action, String url, String json,
                                     final DataResponseListener datalistner) {
        try {

            request = new Request.Builder().url(Const.API_HOST +action+ "/"+url).post(RequestBody.create(JSON, json))/*.header(auth, Pref.getStringValue(context, Const.PREF_USER_TOKEN_SECURITY, ""))*/.build();

            Utils.print(" Url  ::: " + Const.API_HOST + action+ "/"+url);
            Utils.print(" Request  ::: " + json.toString());

            client = new OkHttpClient();
            call = client.newCall(request);

            call.enqueue(new Callback() {
                @Override
                public void onFailure(Request request, IOException arg1) {
                    arg1.printStackTrace();
                    Utils.print("::::::::::::::::::::doPostRequest::::::::::onFailure::::::::::::::::::::::::::::::" + arg1);
                    Utils.print(this.getClass() + " :: Exception :: ", arg1);
                    if (arg1.toString().contains("SocketTimeoutException"))
                        datalistner.onFailure("SocketTimeoutException", arg1);
                    else
                        datalistner.onFailure(call.toString(), arg1);
                }

                @Override
                public void onResponse(Response response) throws IOException {
                    try {
                        Utils.print("  Response response.isSuccessful(): ",
                                response.isSuccessful() + "");

                        if (response.isSuccessful()) {
                            String value = response.body().string();
                            Utils.print(" _____***_____ API Response :::::: " + value);
                            datalistner.onResponse(value);

                        } else
                            datalistner.onFailure("API ISSUE ");

                    } catch (SocketTimeoutException e) {
                        Utils.print(":::::::::::::::::::::doPostRequest:::::::::SocketTimeoutException::::::::::::::::::::::::::::::");
                        e.printStackTrace();
                        datalistner.onFailure("SocketTimeoutException", e);
                    } catch (IOException e) {
                        Utils.print("::::::::::::::::::::doPostRequest::::::::::IOEXCEPTION::::::::::::::::::::::::::::::");
                        e.printStackTrace();
                        datalistner.onFailure("IOEXCEPTION", e);
                    }
                }
            });

            // call.execute();

        } catch (Exception e) {
            Utils.print("::::::::::::::::::::doPostRequest::::::::::Exception::::::::::::::::::::::::::::::");
            e.printStackTrace();
            datalistner.onFailure("EXCEPTION", e);

        } finally {
            client = null;
            request = null;
        }
    }

    public static void doGetRequest(String action, final DataResponseListener datalistner) {

        try {

            Utils.print(" Url  ::: ", action);

            client = new OkHttpClient();
            request = new Request.Builder().url(action).build();
            call = client.newCall(request);

            call.enqueue(new Callback() {
                @Override
                public void onFailure(Request request, IOException arg1) {
                    Utils.print(this.getClass() + " :: Exception :: ", arg1);
                    if (arg1.toString().contains("SocketTimeoutException"))
                        datalistner.onFailure("SocketTimeoutException", arg1);
                    else
                        datalistner.onFailure(request.toString(), arg1);
                }

                @Override
                public void onResponse(Response response) throws IOException {
                    Utils.print(" Code ::: " + response.code());
                    try {
                        if (response.isSuccessful()) {
                            String value = response.body().string();
                            Utils.print(" Api Response:::  ::: " + value);

                            datalistner.onResponse(value);
                        } else
                            datalistner.onFailure("API ISSUE ");

                    } catch (SocketTimeoutException e) {
                        Utils.print(":::::::::::::::::::::doGetRequest:::::::::SocketTimeoutException::::::::::::::::::::::::::::::");
                        e.printStackTrace();
                        datalistner.onFailure("SocketTimeoutException", e);
                    } catch (IOException e) {
                        e.printStackTrace();
                        datalistner.onFailure("IOEXCEPTION", e);
                    }
                }
            });

            // call.execute();

        } catch (Exception e) {
            e.printStackTrace();
            datalistner.onFailure("EXCEPTION", e);

        } finally {
            client = null;
            request = null;
        }
    }

    public static void doCancel() {
        /*
         * if(call!=null) call.cancel();
         */
    }
}
