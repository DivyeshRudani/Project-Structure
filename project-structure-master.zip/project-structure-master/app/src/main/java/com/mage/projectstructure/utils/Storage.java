package com.mage.projectstructure.utils;

import android.graphics.Bitmap;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Storage {

    public static void verifyDataPath() throws IOException {
        verifyHomePath();
        File dir = new File(Const.DIR_USERDATA);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        dir = null;
    }

    public static void verifyHomePath() throws IOException {
        File dir = new File(Const.APP_HOME);

        if (!dir.exists()) {
            dir.mkdirs();
        }

        dir = null;
    }


    public static void CopyStream(InputStream is, OutputStream os) {
        final int buffer_size = 1024;
        try {
            byte[] bytes = new byte[buffer_size];
            for (; ; ) {
                int count = is.read(bytes, 0, buffer_size);
                if (count == -1)
                    break;
                os.write(bytes, 0, count);
            }
        } catch (Exception ex) {
        }
    }


    public static void delete(String f) throws IOException {
        File file = new File(f);

        if (file.exists()) {
            file.delete();
        }

        file = null;
        f = null;
    }

    public static boolean deleteDirectory(File path) {
        if (path.exists()) {
            File[] files = path.listFiles();
            if (files == null) {
                return true;
            }
            for (int i = 0; i < files.length; i++) {
                if (files[i].isDirectory()) {
                    deleteDirectory(files[i]);
                } else {
                    files[i].delete();
                }
            }
        }
        return (path.delete());
    }

    public static String SaveBitmapInSdCardWithSting(Bitmap bm) {
        OutputStream fOut = null;
        File f = null;
        if (bm == null)
            return "";

        try {
            Utils.deleteDirectory(new File(Const.DIR_USERDATA));
            Storage.verifyDataPath();
            f = new File(new File(Const.DIR_USERDATA), "temp.jpg");
            fOut = new FileOutputStream(f);
        } catch (Exception e) {

            Utils.print("Storage  SaveBitmapInSdCard:: Exception :: ", e);
            Utils.print(" Storage  SaveBitmapInSdCard :: Exception :: ", e);
        }

        try {
            bm.compress(Bitmap.CompressFormat.PNG, 100, fOut);
            fOut.flush();
            fOut.close();
        } catch (Exception e) {

            Utils.print("Storage  SaveBitmapInSdCard:: Exception :: ", e);
            Utils.print(" Storage  SaveBitmapInSdCard :: Exception :: ", e);
        }

        return f != null ? f.getAbsolutePath().toString() : "";
    }

    public static String SaveBitmapInSdCard(Bitmap bm, String imgName) {
        OutputStream fOut = null;
        File f = null;
        if (bm == null)
            return "";

        try {
            Storage.deleteDirectory(new File(Const.DIR_USERDATA));
            Storage.verifyDataPath();
            f = new File(new File(Const.DIR_USERDATA), "" + imgName + ".jpg");
            fOut = new FileOutputStream(f);
        } catch (Exception e) {

            Utils.print(" Storage  SaveBitmapInSdCard :: Exception :: ", e);
        }

        try {
            bm.compress(Bitmap.CompressFormat.PNG, 100, fOut);
            fOut.flush();
            fOut.close();
        } catch (Exception e) {

            Utils.print(" Storage  SaveBitmapInSdCard :: Exception :: ", e);
        }

        return f != null ? f.getAbsolutePath().toString() : "";
    }

}