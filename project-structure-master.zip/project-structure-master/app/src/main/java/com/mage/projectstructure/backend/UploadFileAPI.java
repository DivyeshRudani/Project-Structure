package com.mage.projectstructure.backend;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;


import com.mage.projectstructure.listener.ResponseListener;
import com.mage.projectstructure.uc.AlertDailogView;
import com.mage.projectstructure.utils.Const;
import com.mage.projectstructure.utils.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;


public class UploadFileAPI extends AsyncTask<String, Void, Integer> {

    public Context mCaller;
    public ResponseListener responseListener;
    public MultipartRequest multipartReq;

    public File file = null;
    public ArrayList<String> imgList = null;
    String mesg = "";
    private String img = "";
    private String img1 = "";
    private String img2 = "";
    private String img3 = "";
    private String imagID = "";

    public UploadFileAPI(Context caller, ResponseListener responseListener, String img, String img1, String img2, String img3) {

        this.mCaller = caller;
        this.responseListener = responseListener;
        this.img = img;
        this.img1 = img1;
        this.img2 = img2;
        this.img3 = img3;

    }

    @Override
    protected Integer doInBackground(String... params) {
        int result = -1;

        try {
            multipartReq = new MultipartRequest(mCaller);

            if (!img.isEmpty()) {

               //URL url = new URL(img);
                file = new File(img);
                Utils.print("FILE NAME : "+ file.getName());
                if (file.exists()) {
                    Utils.print("FILE : "+ file.toString());
                    multipartReq.addFile("image[]", file.toString(), file.getName());
                }
            }

            if (!img1.isEmpty()) {
                file = new File(img1);
                if (file.exists()) {
                    multipartReq.addFile("image2", file.toString(), file.getName());
                }
            }

            if (!img2.isEmpty()) {
                file = new File(img2);
                if (file.exists()) {
                    // Log.print("File name::::"+file.toString()+"name::"+file.getName());
                    multipartReq.addFile("image3", file.toString(), file.getName());
                }
            }

            if (!img3.isEmpty()) {
                file = new File(img3);
                if (file.exists()) {
                    // Log.print("File name::::"+file.toString()+"name::"+file.getName());
                    multipartReq.addFile("image4", file.toString(), file.getName());
                }
            }

            result = parse(multipartReq.execute(Const.API_HOST_IMAGE_UPLOAD));

        } catch (Exception e) {
            result = -1;
            mesg = "Unable to upload please try again.";
            Utils.print(e);
            Utils.print(this.getClass() + "", e);
        }
        return result;
    }

    private String compressImage(String imageUri) {

        String filePath = getRealPathFromURI(imageUri);
        Bitmap scaledBitmap = null;

        BitmapFactory.Options options = new BitmapFactory.Options();

//      by setting this field as true, the actual bitmap pixels are not loaded in the memory. Just the bounds are loaded. If
//      you try the use the bitmap here, you will get null.
        options.inJustDecodeBounds = true;
        Bitmap bmp = BitmapFactory.decodeFile(filePath, options);

        int actualHeight = options.outHeight;
        int actualWidth = options.outWidth;


//      max Height and width values of the compressed image is taken as 816x612

        float maxHeight = 816.0f;
        float maxWidth = 612.0f;
        float imgRatio = actualWidth / actualHeight;
        float maxRatio = maxWidth / maxHeight;


        //      width and height values are set maintaining the aspect ratio of the image

        if (actualHeight > maxHeight || actualWidth > maxWidth) {
            if (imgRatio < maxRatio) {
                imgRatio = maxHeight / actualHeight;
                actualWidth = (int) (imgRatio * actualWidth);
                actualHeight = (int) maxHeight;
            } else if (imgRatio > maxRatio) {
                imgRatio = maxWidth / actualWidth;
                actualHeight = (int) (imgRatio * actualHeight);
                actualWidth = (int) maxWidth;
            } else {
                actualHeight = (int) maxHeight;
                actualWidth = (int) maxWidth;

            }
        }

        //      setting inSampleSize value allows to load a scaled down version of the original image

        options.inSampleSize = calculateInSampleSize(options, actualWidth, actualHeight);

//      inJustDecodeBounds set to false to load the actual bitmap
        options.inJustDecodeBounds = false;

//      this options allow android to claim the bitmap memory if it runs low on memory
        options.inPurgeable = true;
        options.inInputShareable = true;
        options.inTempStorage = new byte[16 * 1024];

        try {
//          load the bitmap from its path
            bmp = BitmapFactory.decodeFile(filePath, options);
        } catch (OutOfMemoryError exception) {
            exception.printStackTrace();

        }
        try {
            scaledBitmap = Bitmap.createBitmap(actualWidth, actualHeight, Bitmap.Config.ARGB_8888);
        } catch (OutOfMemoryError exception) {
            exception.printStackTrace();
        }

        float ratioX = actualWidth / (float) options.outWidth;
        float ratioY = actualHeight / (float) options.outHeight;
        float middleX = actualWidth / 2.0f;
        float middleY = actualHeight / 2.0f;

        Matrix scaleMatrix = new Matrix();
        scaleMatrix.setScale(ratioX, ratioY, middleX, middleY);

        Canvas canvas = new Canvas(scaledBitmap);
        canvas.setMatrix(scaleMatrix);
        canvas.drawBitmap(bmp, middleX - bmp.getWidth() / 2, middleY - bmp.getHeight() / 2, new Paint(Paint.FILTER_BITMAP_FLAG));

//      check the rotation of the image and display it properly
        ExifInterface exif;
        try {
            exif = new ExifInterface(filePath);

            int orientation = exif.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, 0);
            Log.d("EXIF", "Exif: " + orientation);
            Matrix matrix = new Matrix();
            if (orientation == 6) {
                matrix.postRotate(90);
                Log.d("EXIF", "Exif: " + orientation);
            } else if (orientation == 3) {
                matrix.postRotate(180);
                Log.d("EXIF", "Exif: " + orientation);
            } else if (orientation == 8) {
                matrix.postRotate(270);
                Log.d("EXIF", "Exif: " + orientation);
            }else if (orientation == 1){
                matrix.postRotate(0);
                Log.d("EXIF", "Exif: " + orientation);
            }
            scaledBitmap = Bitmap.createBitmap(scaledBitmap, 0, 0,
                    scaledBitmap.getWidth(), scaledBitmap.getHeight(), matrix,
                    true);
        } catch (IOException e) {
            e.printStackTrace();
        }

        FileOutputStream out = null;
        String filename = getFilename();
        try {
            out = new FileOutputStream(filename);

//          write the compressed bitmap at the destination specified by filename.
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return filename;
    }

    public int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            final int heightRatio = Math.round((float) height / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);
            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
        }
        final float totalPixels = width * height;
        final float totalReqPixelsCap = reqWidth * reqHeight * 2;
        while (totalPixels / (inSampleSize * inSampleSize) > totalReqPixelsCap) {
            inSampleSize++;
        }

        return inSampleSize;
    }

    private String getRealPathFromURI(String contentURI) {
        Uri contentUri = Uri.parse(contentURI);
        Cursor cursor = mCaller.getContentResolver().query(contentUri, null, null, null, null);
        if (cursor == null) {
            return contentUri.getPath();
        } else {
            cursor.moveToFirst();
            int index = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            return cursor.getString(index);
        }
    }

    protected void onPostExecute(Integer result) {

        if (result == 1) {// successful
            this.responseListener.onResponse(Const.UPLOAD, Const.API_RESULT.SUCCESS, imagID);
        } else if (result > 0) {
            AlertDailogView.showAlert(mCaller, "Alert", this.mesg, false);
            this.responseListener.onResponse(Const.UPLOAD, Const.API_RESULT.FAIL, null);
        } else {
            if (this.mCaller instanceof Activity) {
                if (result == -1 || result == -2 || result == -3) {
                    AlertDailogView.showAlert(mCaller, mesg, this.mesg, false);
                } else if (result == -4) {
                    AlertDailogView.showAlert(mCaller, mesg, this.mesg, false);
                }
                this.responseListener.onResponse(Const.UPLOAD, Const.API_RESULT.FAIL, this.mesg);
            }
        }
    }

    public int parse(String response) {
        int code = 0;
        Utils.print(":::___File Upload Response::: " + response);
        JSONObject jsonDoc = null;
        JSONObject jsonData = null;
        try {
            jsonDoc = new JSONObject(response);
            code = jsonDoc.getInt("status");

            if (code == 1) {
                imgList = new ArrayList<String>();
//                Const.CAPTURED_IMAGE = "";
                /*{"data":"Image uploaded successfully.","image_name":"1475570966.png","status":"1"}*/

                if (!jsonDoc.isNull("data")) {
                    jsonData = jsonDoc.getJSONObject("data");

                    JSONArray jsonArrayImage = jsonData.getJSONArray("image");

                    imagID = jsonArrayImage.getString(0);

                    Utils.print("IMAGE : "+imagID);

                    //imagID = jsonData.optInt("image") + "";
                   /* if (!jsonData.isNull("image_url")) {
                        //Pref.setStringValue(mCaller, Const.PREF_PROFILE_PIC, jsonData.optString("image_url"));
                    }*/
                }

                Utils.print("____^^^^^ Message :::: " + mesg);
            }
        } catch (Exception e) {
            code = -4;
            Utils.print(this.getClass() + " :: parse()", e);
            e.printStackTrace();
        } finally {
            response = null;
            /** release variables */
            jsonDoc = null;
        }
        return code;
    }

    public String getFilename() {
        File file = new File(Environment.getExternalStorageDirectory().getPath(), "DCIM/Camera");
        if (!file.exists()) {
            file.mkdirs();
        }
        String uriSting = (file.getAbsolutePath() + "/" + System.currentTimeMillis() + ".jpg");
        return uriSting;

    }
}