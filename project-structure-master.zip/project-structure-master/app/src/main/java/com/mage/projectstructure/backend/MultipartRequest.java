package com.mage.projectstructure.backend;

import android.content.Context;

import com.mage.projectstructure.R;
import com.mage.projectstructure.utils.Const;
import com.mage.projectstructure.utils.Pref;
import com.mage.projectstructure.utils.Utils;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.MultipartBuilder;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class MultipartRequest {

    public Context caller;
    public MultipartBuilder builder;
    private OkHttpClient client;

    public MultipartRequest(Context caller) {
        this.caller = caller;
        this.builder = new MultipartBuilder();
        this.builder.type(MultipartBuilder.FORM);
        this.client = new OkHttpClient();
        this.client.setConnectTimeout(30, TimeUnit.SECONDS); // connect timeout
        this.client.setReadTimeout(30, TimeUnit.SECONDS);    // socket timeout
    }

    public void addString(String name, String value) {
        this.builder.addFormDataPart(name, value);
    }

    public void addFile(String name, String filePath, String fileName) {
        Utils.print(" ================================ add File =================");
        Utils.print(" ________Name :: " + name);
        Utils.print(" ________filePath :: " + filePath);
        Utils.print(" ________fileName :: " + fileName);
        this.builder.addFormDataPart("imageType", Pref.getStringValue(caller, Const.PREF_IMAGE_TYPE, ""));//File upload : profile->1 and product->2
        this.builder.addFormDataPart(name, fileName, RequestBody.create(MediaType.parse("image/jpeg"), new File(filePath)));
        Utils.print(" ================================ add File END =================");
    }

    public String execute(String url) {

        RequestBody requestBody = null;
        Request request = null;
        Response response = null;

        int code = 200;
        String strResponse = null;

        try {
            requestBody = this.builder.build();
            request = new Request.Builder().url(url).post(requestBody).build();

            Utils.print("::::::: REQ :: " + request);
            Utils.print("::::::: REQ :: " + requestBody.toString());
            response = client.newCall(request).execute();
            Utils.print("::::::: response :: " + response);

            if (!response.isSuccessful())
                throw new IOException();

            code = response.networkResponse().code();

            if (response.isSuccessful()) {
                strResponse = response.body().string();
                Utils.print(" UPLOAD IMAGE RESPONSE ::: " + strResponse);
            } else if (code == 404) {//SC_NOT_FOUND
                // ** "Invalid URL or Server not available, please try again" */
                strResponse = caller.getResources().getString(
                        R.string.error_invalid_URL);
            } else if (code == 408) {
                // * "Connection timeout, please try again", */
                strResponse = caller.getResources().getString(R.string.error_timeout);
            } else if (code == 503) {
                // *
                // "Invalid URL or Server is not responding, please try again",
                // */
                strResponse = caller.getResources().getString(
                        R.string.error_server_not_responding);
            }
        } catch (Exception e) {
            Utils.print("Exception", e);
            Utils.print(e);
        } finally {
            requestBody = null;
            request = null;
            response = null;
            builder = null;
            if (client != null)
                client = null;
            System.gc();
        }
        return strResponse;
    }
}