package com.mage.projectstructure.uc;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;

import com.mage.projectstructure.R;


public class AlertDailogView {

    // Handle Ok Button by current activity
    public static final int BUTTON_OK = 1;
    // Handle Cancel Button by current activity
    public static final int BUTTON_CANCEL = 2;
    static AlertDialog alert = null;

    public static Dialog showAlert(Context context, String message, boolean showTitle) {
        return showAlert(context, context.getString(R.string.Alert), message,
                context.getString(R.string.OK), false, "", null, 1, showTitle);
    }

    public static Dialog showAlert(Context context, String Title,
                                   String message, int tag) {
        return showAlert(context, Title, message,
                context.getString(R.string.OK), false, "", null, tag, false);
    }

    public static Dialog showAlert(Context context, String message,
                                   String btnText, boolean showTitle) {
        return showAlert(context, context.getString(R.string.Alert), message,
                btnText, false, "", null, 1, showTitle);
    }

    public static Dialog showAlert(Context context, String message,
                                   String btnText, OnCustomPopUpDialogButtonClickListener clickListener) {
        return showAlert(context, context.getString(R.string.Alert), message,
                btnText, false, "", clickListener, 1, true);
    }

    public static Dialog showAlert(Context context, String message,
                                   String btnText, OnCustomPopUpDialogButtonClickListener clickListener,
                                   int tag) {
        return showAlert(context, context.getString(R.string.Alert), message,
                btnText, false, "", clickListener, tag, true);
    }

    public static Dialog showAlert(Context context, String title,
                                   String message, String btnText,
                                   OnCustomPopUpDialogButtonClickListener clickListener) {
        return showAlert(context, title, message, btnText, false, "",
                clickListener, 1, true);
    }

    public static Dialog showAlert(Context context, String message,
                                   String btnTitle_1, boolean isCancelButton, String btnTitle_2,
                                   final OnCustomPopUpDialogButtonClickListener clickListener,
                                   final int tag) {
        return showAlert(context, context.getString(R.string.Alert), message,
                btnTitle_1, isCancelButton, btnTitle_2, clickListener, tag, true);
    }

    // Create Custom popup Alert dailog here
    public static AlertDialog showAlert(Context context, String title,
                                        String message, String btnTitle_1, boolean isCancelButton,
                                        String btnTitle_2,
                                        final OnCustomPopUpDialogButtonClickListener clickListener,
                                        final int tag, boolean showTitle) {

        if (alert != null && alert.isShowing())
            alert.dismiss();
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        if (showTitle)
            builder.setMessage(message).setTitle(title);
        else
            builder.setMessage(message);

        builder.setPositiveButton(btnTitle_1,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                        if (clickListener != null)
                            clickListener.OnButtonClick(tag,
                                    AlertDailogView.BUTTON_OK);
                    }
                });

        if (isCancelButton) {
            builder.setNegativeButton(btnTitle_2,
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            if (clickListener != null)
                                clickListener.OnButtonClick(tag,
                                        AlertDailogView.BUTTON_CANCEL);
                        }
                    });
        }

        alert = builder.create();


        return alert;
    }

    // define Listener here
    public interface OnCustomPopUpDialogButtonClickListener {
        public abstract void OnButtonClick(int tag, int buttonIndex);
    }

}
