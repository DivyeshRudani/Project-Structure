package com.mage.projectstructure.utils;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    public Context context;

    public DBHelper(Context context) {
        super(context, Const.DB_NAME, null, 1);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void execute(String statment) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            db.execSQL(statment);

        } catch (Exception e) {
            Utils.print(e);
        } finally {
            db.close();
            db = null;
        }
    }

    public Cursor query(String statment) {
        Cursor cur = null;
        SQLiteDatabase db = this.getReadableDatabase();
        try {
            cur = db.rawQuery(statment, null);
            cur.moveToPosition(-1);
        } catch (Exception e) {
            Utils.print(e);
        } finally {

            db.close();
            db = null;
        }

        return cur;
    }

    public static String getDBStr(String str) {

        str = str != null ? str.replaceAll("'", "''") : null;
        str = str != null ? str.replaceAll("&#039;", "''") : null;
        str = str != null ? str.replaceAll("&amp;", "&") : null;

        return str;

    }

    public boolean isExistRecord(String tableName, String Key, String Value,
                                 SQLiteDatabase db, DBHelper dbHelper) {
        return isExistRecord(tableName, Key, Value, false, "", "", db, dbHelper);
    }

    public boolean isExistRecord(String tableName, String Key, String Value,
                                 boolean isTwoFiled, String SecondKey, String SecondValue,
                                 SQLiteDatabase db, DBHelper dbHelper) {
        return isExistRecord(tableName, Key, Value, isTwoFiled, SecondKey,
                SecondValue, false, "", "", db, dbHelper);
    }

    public boolean isExistRecord(String tableName, String Key, String Value,
                                 boolean isTwoFiled, String SecondKey, String SecondValue,
                                 boolean isThreeFild, String ThirdKey, String ThirdValue,
                                 SQLiteDatabase db, DBHelper dbHelper) {

        return isExistRecord(tableName, Key, Value, isTwoFiled, SecondKey,
                SecondValue, isThreeFild, ThirdKey, ThirdValue, false, "", "",
                db, dbHelper);

    }

    public boolean isExistRecord(String tableName, String Key, String Value,
                                 boolean isTwoFiled, String SecondKey, String SecondValue,
                                 boolean isThreeFild, String ThirdKey, String ThirdValue,
                                 boolean isForeFild, String ForeKey, String ForeValue,
                                 SQLiteDatabase db, DBHelper dbHelper) {

        String sql = null;
        Cursor cur = null;
        boolean isExist = false;
        boolean isCloseDb = false;
        if (db == null) {
            isCloseDb = true;
            dbHelper = new DBHelper(context);
            db = dbHelper.getReadableDatabase();

        }
        try {

            if (isForeFild)
                sql = "SELECT COUNT(" + Key + ") FROM " + tableName + " WHERE "
                        + Key + " = '" + Value + "' AND " + SecondKey + " = '"
                        + SecondValue + "' AND " + ThirdKey + " = '"
                        + ThirdValue + "' AND " + ForeKey + " = '" + ForeValue
                        + "'";
            else if (isThreeFild)
                sql = "SELECT COUNT(" + Key + ") FROM " + tableName + " WHERE "
                        + Key + " = '" + Value + "' AND " + SecondKey + " = '"
                        + SecondValue + "' AND " + ThirdKey + " = '"
                        + ThirdValue + "'";
            else if (isTwoFiled)
                sql = "SELECT COUNT(" + Key + ") FROM " + tableName + " WHERE "
                        + Key + " = '" + Value + "' AND " + SecondKey + " = '"
                        + SecondValue + "'";
            else
                sql = "SELECT COUNT(" + Key + ") FROM " + tableName + " WHERE "
                        + Key + " = '" + Value + "'";

            cur = db.rawQuery(sql, null);
            cur.moveToPosition(-1);

            if (cur != null) {
                while (cur.moveToNext()) {
                    isExist = cur.getInt(0) > 0;
                }
            }

        } catch (Exception e) {
            Utils.print(getClass() + " :: insertUpdate()", " " + e);
            e.printStackTrace();
        } finally {
            // release
            if (isCloseDb) {
                if (db != null)
                    db.close();
                if (cur != null)
                    cur.close();
                if (dbHelper != null)
                    dbHelper.close();

                db = null;
                dbHelper = null;
            }
            cur = null;
            sql = null;
        }

        return isExist;

    }

    public void upgrade(int level) {
        switch (level) {
            case 0:
                doUpdate1();
                break;
            case 1:
                // doUpdate2();
                break;
            case 2:
                // doUpdate3();
                break;
            case 3:
                // doUpdate4();
                break;
        }
    }

    private void doUpdate1() {


        this.execute("CREATE TABLE IF NOT EXISTS Note ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,img_path TEXT,store_name TEXT,store_location Text,reason TEXT)");

    }

}
