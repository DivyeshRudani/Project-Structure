package com.mage.projectstructure.listener;


public interface DataResponseListener {
    public void onResponse(String result);

    public void onFailure(String fail);

    public void onFailure(String request, Exception error);
}
