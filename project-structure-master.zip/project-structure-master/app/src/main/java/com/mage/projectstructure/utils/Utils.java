package com.mage.projectstructure.utils;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.location.LocationManager;
import android.media.ExifInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.FileProvider;
import android.text.Html;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.mage.projectstructure.R;
import com.mage.projectstructure.common.CustomDialog;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.channels.FileChannel;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utils {

    final public static int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 124;
    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    public static boolean DO_SOP = true;
    public static String DB_PATH
            = "/data/data/" + "com.churchplus" + "/databases/";
    public static String DB_NAME = "Churchplus";

    public static void print(String mesg) {
        if (Utils.DO_SOP) {
            System.out.println(mesg);
//            Log.i("",mesg);
        }
    }

    public static void print(String title, String mesg) {
        if (Utils.DO_SOP) {
            Utils.print(title + " :: " + mesg);
        }
    }

    public static void print(String title, Exception e) {
        if (Utils.DO_SOP) {
            e.printStackTrace();
        }
    }

    public static void print(Exception e) {
        if (Utils.DO_SOP) {
            e.printStackTrace();
        }
    }

    public static boolean isTablet(Context context) {
        boolean xlarge = ((context.getResources().getConfiguration().screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) >= 4);
        boolean large = ((context.getResources().getConfiguration().screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) >= Configuration.SCREENLAYOUT_SIZE_LARGE);
        return (xlarge || large);
    }

    public static boolean validateEmail(String email) {
        if (email
                .matches("\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*")
                && email.length() > 0) {
            return true;
        }
        return false;
    }

    public static void systemUpgrade(Context context) {
        DBHelper dbHelper = new DBHelper(context);
        int level = Pref.getIntValue(context, "LEVEL", 0);
        if (level == 0) {
            dbHelper.upgrade(level);

            // Create not confirmed order
            level++;
        }
        Pref.setIntValue(context, "LEVEL", level);
    }

    //Delete Folder
    public static boolean deleteDirectory(File path) {
        if (path.exists()) {
            File[] files = path.listFiles();
            if (files == null) {
                return true;
            }
            for (int i = 0; i < files.length; i++) {
                if (files[i].isDirectory()) {
                    deleteDirectory(files[i]);
                } else {
                    files[i].delete();
                }
            }
        }
        return (path.delete());
    }

    public static boolean ValidateEmail(String email) {
        Pattern pattern = Pattern
                .compile("[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}");
        // Pattern pattern = Patterns.EMAIL_ADDRESS;
        return pattern.matcher(email).matches();
    }

    // Check Network Status
    public static boolean isOnline(Context context) {
        try {
            ConnectivityManager conMgr = (ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo info = conMgr.getActiveNetworkInfo();
            if (info != null && info.isConnected())
                return true;
            else
                Toast.makeText(context, context.getResources().getString(R.string.No_internet_available), Toast.LENGTH_SHORT).show();
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            // Log.error("Utils :: isonline() ", e);
            return false;
        }
    }

    // Check Network Status
    public static boolean isOnlineWithoutToast(Context context) {
        try {
            ConnectivityManager conMgr = (ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo info = conMgr.getActiveNetworkInfo();
            if (info != null && info.isConnected())
                return true;
           /* else
                Toast.makeText(context, context.getResources().getString(R.string.No_internet_available), Toast.LENGTH_SHORT).show();*/
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            // Log.error("Utils :: isonline() ", e);
            return false;
        }
    }


    public static Bitmap decodeUri(Context context, String selectedImage) {
        Bitmap bmp = null;
        FileOutputStream outStream = null;
        int per;
        try {

            // Decode image size
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            bmp = BitmapFactory.decodeStream(new FileInputStream(new File(
                    selectedImage)), null, o);

            // Find the correct scale value. It should be the power of 2.
            int width = o.outWidth, height = o.outHeight;

            BitmapFactory.Options o2 = new BitmapFactory.Options();

            o2.inJustDecodeBounds = false;
            o2.inSampleSize = 1;
            if ((height > width && height > 640 && width > 480)
                    || (height < width && height > 480 && width > 640)) {
                if (height > width) {
                    o2.inSampleSize = (int) Math.ceil((height / 640.0));
                } else {
                    o2.inSampleSize = (int) Math.ceil((width / 640.0));
                }
                // decode file stream
                bmp = BitmapFactory.decodeStream(new FileInputStream(new File(
                        selectedImage)), null, o2);

                // get dimension
                height = bmp.getHeight();
                width = bmp.getWidth();

                // change dimension
                if ((height > width && height > 640 && width > 480)
                        || (height < width && height > 480 && width > 640)) {
                    if (height > width) {
                        per = (640 * 100) / height;
                        height = 640;
                        width = (per * width) / 100;
                    } else {
                        per = (640 * 100) / width;
                        width = 640;
                        height = (per * height) / 100;
                    }
                    // resize bitmap
                    bmp = Bitmap.createScaledBitmap(bmp, width, height, false);

                }
            }

            // Decode with inSampleSize
            bmp = BitmapFactory.decodeStream(new FileInputStream(new File(
                    selectedImage)), null, o2);

            if (bmp == null)
                bmp = BitmapFactory.decodeStream(new FileInputStream(new File(
                        selectedImage)));

            // save image
            outStream = new FileOutputStream(selectedImage);
            bmp.compress(CompressFormat.JPEG, 100, outStream);
            outStream.close();
            outStream = null;

            return bmp;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static int indexOfStringArray(String[] strArray, String strFind) {
        int index;
        for (index = 0; index < strArray.length; index++)
            if (strArray[index].equals(strFind))
                break;

        Utils.print("___________indexOfStringArray________ :: " + index);

        return index >= strArray.length ? 0 : index;
    }

    public static String millisToDate(long millis, String format) {
        return new SimpleDateFormat(format).format(new Date(millis));
    }

    public static Date millisTonCurrentDate(long millis, String format) {
        try {
            return new SimpleDateFormat(format).parse(Utils.millisToDate(millis, format));
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static int getDaysDifference(Date d2) {
        int daysdiff = 0;
        long diff = d2.getTime() - System.currentTimeMillis();
        long diffDays = diff / (24 * 60 * 60 * 1000);
        daysdiff = (int) diffDays;
        return daysdiff;
    }

    public static Date convertStringToDate(String strDate, String parseFormat) {
        try {
            return new SimpleDateFormat(parseFormat).parse(strDate);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String convertDateStringToString(String strDate,
                                                   String currentFormat, String parseFormat) {

        Utils.print("=========== strDate" + strDate);
        Utils.print("=========== currentFormat" + currentFormat);
        Utils.print("=========== parseFormat" + parseFormat);
        try {
            return convertDateToString(
                    convertStringToDate(strDate, currentFormat), parseFormat);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String convertDateToString(Date objDate, String parseFormat) {
        try {
            return new SimpleDateFormat(parseFormat).format(objDate);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static void showProgress(Context context) {
        try {
            if (Const.custDailog != null && Const.custDailog.isShowing())
                Const.custDailog.dismiss();

            if (Const.custDailog == null)
                Const.custDailog = new CustomDialog(context);
            Const.custDailog.setCancelable(false);
            Const.custDailog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void dismissProgress() {
        if (Const.custDailog != null && Const.custDailog.isShowing())
            Const.custDailog.dismiss();
        Const.custDailog = null;
    }

    @SuppressWarnings("unused")
    private static void copyFileUsingFileChannels(File source, File dest)
            throws IOException {
        FileInputStream fis = null;
        FileOutputStream out = null;

        FileChannel inputChannel = null;
        FileChannel outputChannel = null;
        try {
            inputChannel = new FileInputStream(source).getChannel();
            outputChannel = new FileOutputStream(dest).getChannel();
            outputChannel.transferFrom(inputChannel, 0, inputChannel.size());
        } finally {
            inputChannel.close();
            outputChannel.close();
        }
    }

    public static void logOut(Context context) {

       /* Utils.closeAllScreens();
        Intent intent = new Intent(context, LoginActivity.class);
        context.startActivity(intent);*/
    }

    public static void addActivities(String key, Activity _activity) {
        if (Const.screen_al == null)
            Const.screen_al = new HashMap<String, Activity>();
        if (_activity != null)
            Const.screen_al.put(key, _activity);
    }

    public static void closeAllScreens() {
        closeAllScreens("");
    }

    public static void closeAllScreens(String key) {

        if (Const.screen_al == null || Const.screen_al.size() <= 0)
            return;
        if (key != null && !key.equalsIgnoreCase("")) {
            if (Const.screen_al.get(key) != null)
                Const.screen_al.get(key).finish();
        } else {
            for (Iterator<Map.Entry<String, Activity>> it = Const.screen_al
                    .entrySet().iterator(); it.hasNext(); ) {
                Map.Entry<String, Activity> entry = it.next();

                if (entry.getValue() != null) {
                    entry.getValue().finish();
                    it.remove();
                }
            }
        }
    }

    public static String round(String _value, int places) {
        try {
            if (places < 0)
                throw new IllegalArgumentException();

            double value = Double.parseDouble(_value);
            long factor = (long) Math.pow(10, places);
            value = value * factor;
            long tmp = Math.round(value);
            value = (double) tmp / factor;
            return String.valueOf(value);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Converting dp to pixel
     */
    public static int dpToPx(Context context, int dp) {
        Resources r = context.getResources();
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, r.getDisplayMetrics()));
    }

    public static int getDeviceWidth(Context context) {
        DisplayMetrics dm = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay()
                .getMetrics(dm);
        return dm.widthPixels;
    }

    public static int getDeviceHeight(Context context) {
        DisplayMetrics dm = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay()
                .getMetrics(dm);
        return dm.heightPixels;
    }


   /* public static boolean isTablet2(Context context) {
        return context.getResources().getBoolean(R.bool.isTablet);
    }*/

    public static String pad(int c) {
        return c >= 10 ? String.valueOf(c) : "0" + String.valueOf(c);
    }

    public static void hideKeyBoardFromView(Context context) {
        InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService(Activity.INPUT_METHOD_SERVICE);
        // Find the currently focused view, so we can grab the correct window
        // token from it.
        View view = ((Activity) context).getCurrentFocus();
        // If no view currently has focus, create a new one, just so we can grab
        // a window token from it
        if (view == null) {
            view = new View(context);
        }
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static void applyFontFace(Context context, final View view) {

        /*
         * Utils.applyFontFace(this, this.findViewById(android.R.id.content).getRootView());// add to all activity to change fonts
         *
         * GlacialTndifference Regular==100(All header title and more)
         * PlayfairDisplay-Bold.otf==200 (menu item)
         * */

        try {
            if (view instanceof ViewGroup) {

                ViewGroup vg = (ViewGroup) view;
                for (int i = 0; i < vg.getChildCount(); i++) {
                    View child = vg.getChildAt(i);
                    try {

                        applyFontFace(context, child);
                    } catch (NullPointerException e) {
                        continue;
                    }

                }
            } else if (view instanceof CheckBox) {

                if (view.getTag() == null || view.getTag().toString().equalsIgnoreCase("GoogleCopyrights"))
                    return;

                if (Integer.parseInt(view.getTag().toString()) == 100)
                    ((CheckBox) view).setTypeface(Typeface.createFromAsset(context.getAssets(), "Roboto_Medium.ttf"));
                else if (Integer.parseInt(view.getTag().toString()) == 200)
                    ((CheckBox) view).setTypeface(Typeface.createFromAsset(context.getAssets(), "Roboto_Medium.ttf"));
                else if (Integer.parseInt(view.getTag().toString()) == 300)
                    ((CheckBox) view).setTypeface(Typeface.createFromAsset(context.getAssets(), "Roboto_Medium.ttf"));


            } else if (view instanceof Button) {

                if (view.getTag() == null || view.getTag().toString().equalsIgnoreCase("GoogleCopyrights"))
                    return;
                if (Integer.parseInt(view.getTag().toString()) == 100)
                    ((Button) view).setTypeface(Typeface.createFromAsset(context.getAssets(), "Roboto_Medium.ttf"));
                else if (Integer.parseInt(view.getTag().toString()) == 200)
                    ((Button) view).setTypeface(Typeface.createFromAsset(context.getAssets(), "Roboto_Medium.ttf"));
                else if (Integer.parseInt(view.getTag().toString()) == 300)
                    ((Button) view).setTypeface(Typeface.createFromAsset(context.getAssets(), "Roboto_Medium.ttf"));

            } else if (view instanceof EditText) {

                if (view.getTag() == null || view.getTag().toString().equalsIgnoreCase("GoogleCopyrights"))
                    return;
                if (Integer.parseInt(view.getTag().toString()) == 100)
                    ((EditText) view).setTypeface(Typeface.createFromAsset(context.getAssets(), "Roboto_Medium.ttf"));
                else if (Integer.parseInt(view.getTag().toString()) == 200)
                    ((EditText) view).setTypeface(Typeface.createFromAsset(context.getAssets(), "Roboto_Medium.ttf"));
                else if (Integer.parseInt(view.getTag().toString()) == 300)
                    ((EditText) view).setTypeface(Typeface.createFromAsset(context.getAssets(), "Roboto_Medium.ttf"));

            } else if (view instanceof TextView) {

                if (view.getTag() == null || view.getTag().toString().equalsIgnoreCase("GoogleCopyrights"))
                    return;

                if (Integer.parseInt(view.getTag().toString()) == 100)
                    ((TextView) view).setTypeface(Typeface.createFromAsset(context.getAssets(), "Roboto_Medium.ttf"));
                else if (Integer.parseInt(view.getTag().toString()) == 200)
                    ((TextView) view).setTypeface(Typeface.createFromAsset(context.getAssets(), "Roboto_Medium.ttf"));
                else if (Integer.parseInt(view.getTag().toString()) == 300)
                    ((TextView) view).setTypeface(Typeface.createFromAsset(context.getAssets(), "Roboto_Medium.ttf"));

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void toastMessage(Context context, String mgs, boolean isShort) {
        Toast.makeText(context, mgs, isShort ? Toast.LENGTH_SHORT : Toast.LENGTH_SHORT).show();
    }

    public static void snackBar(View view, String mgs, boolean isLong) {
        Snackbar snackbar = Snackbar.make(view, mgs, isLong ? Snackbar.LENGTH_LONG : Snackbar.LENGTH_SHORT);
        snackbar.show();
    }

    /*public static LatLng getLocationFromAddress(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;

        try {
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            p1 = new LatLng(location.getLatitude(), location.getLongitude());

        } catch (Exception ex) {

            ex.printStackTrace();
        }
        return p1;
    }

    *//**
     * Check the device to make sure it has the Google Play Services APK. If
     * it doesn't, display a dialog that allows users to download the APK from
     * the Google Play Store or enable it in the device's system settings.
     *//*
    public static boolean checkPlayServices(Activity activity) {

        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
        int resultCode = apiAvailability.isGooglePlayServicesAvailable(activity);
        if (resultCode != ConnectionResult.SUCCESS) {
            if (apiAvailability.isUserResolvableError(resultCode)) {
                apiAvailability.getErrorDialog(activity, resultCode, PLAY_SERVICES_RESOLUTION_REQUEST)
                        .show();
            } else {
                android.util.Log.i("==checkPlayServices==", "This device is not supported.");
                activity.finish();
            }
            return false;
        }
        return true;
    }*/

    /**
     * For TAKE PICTURE from Camera
     */

    public static void startCapture(Activity activity) {

        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if (cameraIntent.resolveActivity(activity.getPackageManager()) != null) {

            File photoFile = null;
            String timeStamp = System.currentTimeMillis() + "";

            try {

                Storage.verifyDataPath();
                // Const.CAPTURED_IMAGE = Const.DIR_USERDATA + "/"+ timeStamp + ".jpg";
                photoFile = File.createTempFile(timeStamp, ".jpg", new File(Const.DIR_USERDATA));
                Const.CAPTURED_IMAGE = photoFile.getAbsolutePath();
                Pref.setStringValue(activity, Const.PREF_CAMERAPATH, Const.CAPTURED_IMAGE);

            } catch (IOException e) {
                Const.CAPTURED_IMAGE = "";
                Pref.setStringValue(activity, Const.PREF_CAMERAPATH, Const.CAPTURED_IMAGE);
                e.printStackTrace();
            }

            if (photoFile != null) {
                Utils.print(" _______________Const.CAPTURED_IMAGE :: " + Const.CAPTURED_IMAGE);
//                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(photoFile));
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, FileProvider.getUriForFile(activity, activity.getPackageName() + ".provider", photoFile));//Uri.fromFile(photoFile)
                cameraIntent.putExtra("return-data", true);
                activity.startActivityForResult(cameraIntent, Const.TAKE_PICTURE);
            }
        }
    }

    /**
     * Profile Pic From FB
     */

    public static String getFacebookProfilePicture(String url) {

        Bitmap bitmap = null;
        InputStream inputStream = null;
        String filename = Const.DIR_USERDATA + "/" + System.currentTimeMillis() + ".jpg";

        try {
            Storage.verifyDataPath();
            inputStream = new URL(url).openConnection().getInputStream();
            BitmapFactory.Options options = new BitmapFactory.Options();
            FileOutputStream fos = new FileOutputStream(filename);
            options.inJustDecodeBounds = false;

            options.inPreferredConfig = Bitmap.Config.RGB_565;
            options.inDither = true;
            options.inSampleSize = 1;
            bitmap = BitmapFactory.decodeStream(inputStream, null, options);
            bitmap.compress(CompressFormat.JPEG, 100, fos);

        } catch (IOException e) {
            e.printStackTrace();
            filename = "";
        } catch (Exception e) {
            e.printStackTrace();
            filename = "";
        } finally {
            bitmap = null;
            inputStream = null;
        }
        return filename;
    }

    public static void getHashKey(Context ctx) {

        try {
            PackageInfo info = ctx.getPackageManager().getPackageInfo(
                    "com.mgs.weout", PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Utils.print(" :: Utils :: __________ Hash Key :  ", Base64.encodeToString(md.digest(), Base64.DEFAULT));
            }
        } catch (PackageManager.NameNotFoundException e) {
            Utils.print(" :: Utils :: ", "" + e);
        } catch (NoSuchAlgorithmException e) {
            Utils.print(" :: Utils :: ", "" + e);
        }
    }

    public static boolean isEmpty(EditText view) {
        return view == null || view.getText().toString().trim().length() == 0;
    }

    public static void tostMessage(Context context, String mgs, boolean isShort) {
       /* //Find custom toast example layout file
        View layoutValue = LayoutInflater.from(context).inflate(R.layout.toast, null);
        //Creating the Toast object
        Toast toast = new Toast(context);
        toast.setDuration(isShort ? Toast.LENGTH_SHORT : Toast.LENGTH_LONG);
        TextView text = (TextView) layoutValue.findViewById(R.id.text);
        text.setText(mgs);
        // gravity, xOffset, yOffset
//        toast.setGravity(Gravity.BOTTOM, 0, 0);
        toast.setView(layoutValue);//setting the view of custom toast layout
        toast.show();*/
        Toast.makeText(context, mgs, isShort ? Toast.LENGTH_SHORT : Toast.LENGTH_LONG).show();
    }

    //check Gps is enable or not
    public static boolean checkGPSStatus(Context context) {
        LocationManager locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        boolean gpsStatus = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        return gpsStatus;
    }

    //enable gps
    public static void checkGPS(final Context context) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage("Your GPS seems to be disabled, do you want to enable it?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        context.startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        dialog.cancel();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
        /*Button nbutton = alert.getButton(DialogInterface.BUTTON_NEGATIVE);
        //Set negative button text color
        nbutton.setTextColor(Color.BLACK);
        Button pbutton = alert.getButton(DialogInterface.BUTTON_POSITIVE);
        //Set positive button text color
        pbutton.setTextColor(Color.BLACK);*/
    }

    //enable gps
    public static void TokenExpired(final Context context, String msg) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(msg)
                .setCancelable(false)
                .setPositiveButton(context.getResources().getString(R.string.login), new DialogInterface.OnClickListener() {
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        Utils.logOut(context);
                    }
                })
               /* .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        dialog.cancel();
                    }
                })*/;
        final AlertDialog alert = builder.create();
        alert.show();
        /*Button nbutton = alert.getButton(DialogInterface.BUTTON_NEGATIVE);
        //Set negative button text color
        nbutton.setTextColor(Color.BLACK);
        Button pbutton = alert.getButton(DialogInterface.BUTTON_POSITIVE);
        //Set positive button text color
        pbutton.setTextColor(Color.BLACK);*/
    }

    //enable gps
    public static void alertMessage(final Context context, String msg) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(msg)
                .setCancelable(false)
                .setPositiveButton(context.getResources().getString(R.string.OK), new DialogInterface.OnClickListener() {
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        dialog.dismiss();
                    }
                })
        ;
        final AlertDialog alert = builder.create();
        alert.show();
    }

    public static Bitmap decodeUri(String imagePath) {
        return decodeUri(imagePath, 768, 400, ScalingLogic.CROP, true);
    }

    public static Bitmap decodeUri(String imgPath, int dstWidth,
                                   int dstHeight, ScalingLogic scalingLogic, boolean isStoreSdCard) {

        FileOutputStream outStream = null;
        Bitmap unscaledBitmap = null;

        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(new FileInputStream(new File(imgPath)),
                    null, options);
            // BitmapFactory.decodeResource(res, resId, options);
            options.inJustDecodeBounds = false;
            options.inSampleSize = calculateSampleSize(options.outWidth,
                    options.outHeight, dstWidth, dstHeight, scalingLogic);
            unscaledBitmap = BitmapFactory.decodeStream(new FileInputStream(
                    new File(imgPath)), null, options);

            if (isStoreSdCard) {
                outStream = new FileOutputStream(imgPath);
                unscaledBitmap.compress(CompressFormat.JPEG, 100, outStream);
                outStream.close();
                outStream = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
        }
        return unscaledBitmap;
    }

    public static int calculateSampleSize(int srcWidth, int srcHeight,
                                          int dstWidth, int dstHeight, ScalingLogic scalingLogic) {
        if (scalingLogic == ScalingLogic.FIT) {
            final float srcAspect = (float) srcWidth / (float) srcHeight;
            final float dstAspect = (float) dstWidth / (float) dstHeight;

            if (srcAspect > dstAspect) {
                return srcWidth / dstWidth;
            } else {
                return srcHeight / dstHeight;
            }
        } else {
            final float srcAspect = (float) srcWidth / (float) srcHeight;
            final float dstAspect = (float) dstWidth / (float) dstHeight;

            if (srcAspect > dstAspect) {
                return srcHeight / dstHeight;
            } else {
                return srcWidth / dstWidth;
            }
        }
    }

    /**
     * Camera Image Rotate after capture
     */


    public static void setCameraImageWithFlip(Context context, String imagePath) {

        Utils.print("===============** setCameraImageWithFlip **==============");

        ExifInterface exif = null;
        Bitmap bmp = null;
        FileOutputStream outStream = null;
//		bmp = decodeUri(context, imagePath);
        bmp = decodeUri(imagePath);
        try {
            exif = new ExifInterface(imagePath);

            int croporientation = exif.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL);
            if (croporientation == 6) {
                bmp = Utils.rotate(bmp, 90, context);
            } else if (croporientation == 8) {
                bmp = Utils.rotate(bmp, 270, context);
            } else if (croporientation == 3) {
                bmp = Utils.rotate(bmp, 180, context);
            }

            // save image
            outStream = new FileOutputStream(imagePath);
            bmp.compress(CompressFormat.JPEG, 100, outStream);
            outStream.close();
            outStream = null;
        } catch (Exception e) {
            Utils.print("Utils :: Exception :: ", e);
            Utils.print("Utils  :: Exception :: ", e);
        }
    }

    public static Bitmap rotate(Bitmap bitmap, int degree, Context context) {

        try {

            Matrix m = new Matrix();
            m.postRotate(degree, (float) bitmap.getWidth() / 2,
                    (float) bitmap.getHeight() / 2);
            try {
                Bitmap b2 = Bitmap.createBitmap(bitmap, 0, 0,
                        bitmap.getWidth(), bitmap.getHeight(), m, true);
                if (bitmap != b2) {
                    bitmap.recycle();
                    bitmap = b2;
                }
            } catch (OutOfMemoryError e) {
                Utils.print(" Utils :: OutOfMemoryError :: ", e.toString());
                Utils.print("Utils  :: OutOfMemoryError :: ", e.toString());
            }
            return bitmap;

        } catch (Exception e) {
            Utils.print(" Utils :: Exception :: ", e);
            Utils.print("Utils  :: Exception :: ", e);
            return null;
        }

    }

    /**
     * Sharing Intent
     */
    public static void shareIntent(Context caller, String text, ImageView img) {
        Bitmap bitmap = null;
        if (img != null)
            bitmap = ((BitmapDrawable) img.getDrawable()).getBitmap();
        Utils.dismissProgress();

        Intent intent1 = new Intent();
        intent1.setAction(Intent.ACTION_SEND);
        if (img != null && bitmap != null) {
            intent1.setType("*/*");
            intent1.putExtra(Intent.EXTRA_STREAM, Uri.parse("file:///" + Storage.SaveBitmapInSdCardWithSting(bitmap)));
        } else
            intent1.setType("text/plain");

        if (!text.isEmpty())
            intent1.putExtra(Intent.EXTRA_TEXT, text);

        Intent openInChooser = Intent.createChooser(intent1, "Share With...");

        caller.startActivity(openInChooser);
    }

    public static void shareIntent(Context caller, String text) {
        Intent intent1 = new Intent();
        intent1.setAction(Intent.ACTION_SEND);
        intent1.setType("text/plain");
        intent1.putExtra(Intent.EXTRA_TEXT, text);

        Intent openInChooser = Intent.createChooser(intent1, "Share With...");

        caller.startActivity(openInChooser);
    }

    public static Date convertDate(String dateString) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd hh:mm aa");
        // String date = yourString.substring(0, 10);
        Date convertedDate = new Date();
        try {
            convertedDate = dateFormat.parse(dateString);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return convertedDate;

    }

    public static void showToast(Context context, String message) {
        try {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void startRecordVideo(Activity activity) {
        try {
            Storage.verifyDataPath();
            Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
            Const.CAPTURED_VIDEOPATH = Const.DIR_USERDATA + File.separator + "VID_" + System.currentTimeMillis() + ".mp4";
            Pref.setStringValue(activity, Const.PREF_VIDEOPATH, Const.CAPTURED_VIDEOPATH);
            // set video quality
            // **==> 1 = high quality with higher file size 0==lower quality and
            // lower file size.
            intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 0);
            intent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 15);// Set Limit Here//--(60 * 3)
            intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(Const.CAPTURED_VIDEOPATH))); // set the image
            // file//
            // name

            // start the video capture Intent
            activity.startActivityForResult(intent, Const.TAKE_VIDEO);
        } catch (IOException e) {
            Utils.print("Utils:: Exception :: ", e);

            Const.CAPTURED_VIDEOPATH = "";
            Pref.setStringValue(activity, Const.PREF_VIDEOPATH,
                    Const.CAPTURED_VIDEOPATH);
        } catch (Exception e1) {
            Utils.print("Utils :: Exception :: ", e1);

            Const.CAPTURED_VIDEOPATH = "";
            Pref.setStringValue(activity, Const.PREF_VIDEOPATH,
                    Const.CAPTURED_VIDEOPATH);
        }
    }

    public static void makeTextViewResizable(final TextView tv, final int maxLine, final String expandText, final boolean viewMore) {

        if (tv.getTag() == null) {
            tv.setTag(tv.getText());
        }
        ViewTreeObserver vto = tv.getViewTreeObserver();
        vto.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {


            @Override
            public void onGlobalLayout() {

                ViewTreeObserver obs = tv.getViewTreeObserver();
                obs.removeGlobalOnLayoutListener(this);
                if (maxLine == 0) {
                    int lineEndIndex = tv.getLayout().getLineEnd(0);
                    String text = tv.getText().subSequence(0, lineEndIndex - expandText.length() + 1) + " " + expandText;
                    tv.setText(text);
                    tv.setMovementMethod(LinkMovementMethod.getInstance());
                    tv.setText(
                            addClickablePartTextViewResizable(Html.fromHtml(tv.getText().toString()), tv, maxLine, expandText,
                                    viewMore), TextView.BufferType.SPANNABLE);
                } else if (maxLine > 0 && tv.getLineCount() >= maxLine) {
                    int lineEndIndex = tv.getLayout().getLineEnd(maxLine - 1);
                    String text = tv.getText().subSequence(0, lineEndIndex - expandText.length() + 1) + " " + expandText;
                    tv.setText(text);
                    tv.setMovementMethod(LinkMovementMethod.getInstance());
                    tv.setText(
                            addClickablePartTextViewResizable(Html.fromHtml(tv.getText().toString()), tv, maxLine, expandText,
                                    viewMore), TextView.BufferType.SPANNABLE);
                } else {
                    int lineEndIndex = tv.getLayout().getLineEnd(tv.getLayout().getLineCount() - 1);
                    String text = tv.getText().subSequence(0, lineEndIndex) + " " + expandText;
                    tv.setText(text);
                    tv.setMovementMethod(LinkMovementMethod.getInstance());
                    tv.setText(
                            addClickablePartTextViewResizable(Html.fromHtml(tv.getText().toString()), tv, lineEndIndex, expandText,
                                    viewMore), TextView.BufferType.SPANNABLE);
                }
            }
        });

    }

    private static SpannableStringBuilder addClickablePartTextViewResizable(final Spanned strSpanned, final TextView tv,
                                                                            final int maxLine, final String spanableText, final boolean viewMore) {
        String str = strSpanned.toString();
        SpannableStringBuilder ssb = new SpannableStringBuilder(strSpanned);

        if (str.contains(spanableText)) {
            ssb.setSpan(new ClickableSpan() {

                @Override
                public void onClick(View widget) {

                    if (viewMore) {
                        tv.setLayoutParams(tv.getLayoutParams());
                        tv.setText(tv.getTag().toString(), TextView.BufferType.SPANNABLE);
                        tv.invalidate();
                        makeTextViewResizable(tv, -1, "View Less", false);
                    } else {
                        tv.setLayoutParams(tv.getLayoutParams());
                        tv.setText(tv.getTag().toString(), TextView.BufferType.SPANNABLE);
                        tv.invalidate();
                        makeTextViewResizable(tv, 2, "View More", true);
                    }
                }
            }, str.indexOf(spanableText), str.indexOf(spanableText) + spanableText.length(), 0);
        }
        return ssb;

    }

    public static String subStringDateWithTime(String postCreatedDate) {
        return postCreatedDate.substring(0, 17);
    }

    public static String subString(String postCreatedDate) {
        return postCreatedDate.substring(0, 11);
    }

    public static String parseDate(String date) {
        String date1;
        try {
            date1 = new SimpleDateFormat("yyyy-MM-dd").format(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.ROOT).parse(date));
        } catch (ParseException e) {
            e.printStackTrace();
            date1 = date;
        }

        return date1;
    }

    public static String parseDateFromCurrentDate(String date) {
        String date1;
        try {
            date1 = new SimpleDateFormat("yyyy-MM-dd").format(new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy",Locale.ROOT).parse(date));
        } catch (ParseException e) {
            e.printStackTrace();
            date1 = date;
        }

        return date1;
    }


    public static String parseYearFromDate(String date) {
        String date1;
        try {
            date1 = new SimpleDateFormat("yyyy").format(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss",Locale.ROOT).parse(date));
        } catch (ParseException e) {
            e.printStackTrace();
            date1 = date;
        }

        return date1;
    }

    public static String parseDateFromDate(String date) {
        String date1;
        try {
            date1 = new SimpleDateFormat("dd").format(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss",Locale.ROOT).parse(date));
        } catch (ParseException e) {
            e.printStackTrace();
            date1 = date;
        }

        return date1;
    }

    public static String parseMonthFromDate(String date) {
        String date1;
        try {
            date1 = new SimpleDateFormat("MM").format(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse(date));
        } catch (ParseException e) {
            e.printStackTrace();
            date1 = date;
        }

        return date1;
    }


    public static String parseDateWithTime(String date) {
        String date1;
        try {
            date1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse(date));
        } catch (ParseException e) {
            e.printStackTrace();
            date1 = date;
        }

        return date1;
    }


    //get video id from youtube url
    public static String getYoutubeVideoIdFromUrl(String inUrl) {
        if (inUrl.toLowerCase().contains("youtu.be")) {
            return inUrl.substring(inUrl.lastIndexOf("/") + 1);
        }/*else if (inUrl.toLowerCase().contains("embed")) {
            return inUrl.substring(inUrl.lastIndexOf("embed/") + 1);
        }*/

        String pattern = "(?<=watch\\?v=|/videos/|embed\\/)[^#\\&\\?]*";
        Pattern compiledPattern = Pattern.compile(pattern);
        Matcher matcher = compiledPattern.matcher(inUrl);
        if (matcher.find()) {
            return matcher.group();
        }
        return null;
    }

    public static void setRunTimePermission(final Activity activity) {

        List<String> permissionsNeeded = new ArrayList<String>();

        final List<String> permissionsList = new ArrayList<String>();

        if (!addPermission(activity, permissionsList, Manifest.permission.INTERNET))
            permissionsNeeded.add(Manifest.permission.INTERNET);
        if (!addPermission(activity, permissionsList, Manifest.permission.ACCESS_NETWORK_STATE))
            permissionsNeeded.add(Manifest.permission.ACCESS_NETWORK_STATE);
        if (!addPermission(activity, permissionsList, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            permissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (!addPermission(activity, permissionsList, Manifest.permission.READ_EXTERNAL_STORAGE))
            permissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        if (!addPermission(activity, permissionsList, Manifest.permission.CAMERA))
            permissionsNeeded.add(Manifest.permission.CAMERA);
        if (!addPermission(activity, permissionsList, Manifest.permission.ACCESS_FINE_LOCATION))
            permissionsNeeded.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (!addPermission(activity, permissionsList, Manifest.permission.ACCESS_COARSE_LOCATION))
            permissionsNeeded.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        if (!addPermission(activity, permissionsList, Manifest.permission.READ_PHONE_STATE))
            permissionsNeeded.add(Manifest.permission.READ_PHONE_STATE);


        if (permissionsList.size() > 0) {

            ActivityCompat.requestPermissions(activity, permissionsList.toArray(new String[permissionsList.size()]),
                    REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);

        }
        return;
    }

    private static boolean addPermission(Activity activity, List<String> permissionsList, String permission) {
        if (ActivityCompat.checkSelfPermission(activity, permission) != PackageManager.PERMISSION_GRANTED) {
            permissionsList.add(permission);
            // Check for Rationale Option
            if (!ActivityCompat.shouldShowRequestPermissionRationale(activity, permission))
                return false;
        }
        return true;
    }

    /**
     * For Pick High Resolution Image
     */

    public static enum ScalingLogic {
        CROP, FIT
    }

}
